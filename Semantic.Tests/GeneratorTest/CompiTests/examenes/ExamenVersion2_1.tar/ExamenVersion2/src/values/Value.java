package values;

/**
 * Created by mac on 12/3/14.
 */
public abstract class Value {
}
