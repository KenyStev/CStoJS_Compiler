/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.expression;

import general.Utils;
import types.BooleanType;
import types.Type;
import values.Value;

/**
 *
 * @author Eduardo
 */
public class NotEqualsNode extends LogicalOperatorNode{

    public NotEqualsNode(ExpressionNode raito, ExpressionNode leftou) {
        super(raito, leftou);
        rules.put(Utils.Char+","+Utils.Char, new BooleanType());
        rules.put(Utils.Float+","+Utils.Float, new BooleanType());
        rules.put(Utils.Int+","+Utils.Int, new BooleanType());
        rules.put(Utils.String+","+Utils.String, new BooleanType());
    }
}
