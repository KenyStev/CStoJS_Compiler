/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.expression;

import general.Utils;
import types.BooleanType;
import types.FloatType;
import types.IntegerType;
import types.Type;
import values.Value;

/**
 *
 * @author Eduardo
 */
public class EqualsNode extends LogicalOperatorNode{

    public EqualsNode(ExpressionNode raito, ExpressionNode leftou) {
        super(raito, leftou);
        
        rules.put(Utils.Int+","+Utils.Int,new BooleanType());
        rules.put(Utils.Bool+","+Utils.Bool,new BooleanType());
        rules.put(Utils.Char+","+Utils.Char,new BooleanType());
        rules.put(Utils.String+","+Utils.String,new BooleanType());
        rules.put(Utils.Float+","+Utils.Float,new BooleanType());
        
    }
}
