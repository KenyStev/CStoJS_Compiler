/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.statement;

import general.ContextManager;
import general.ContextType;
import general.Utils;
import java.util.List;
import javax.naming.Context;
import tree.expression.ExpressionNode;
import tree.expression.IdNode;
import types.IntegerType;
import types.Type;
import values.IntegerValue;
import values.Value;
import general.*;

/**
 *
 * @author Eduardo
 */
public class ForNode extends StatementNode{
    
    IdNode id;

    public ForNode(IdNode id, ExpressionNode initialValue, ExpressionNode finalValue, List<StatementNode> statements) {
        this.id = id;
        this.initialExpression = initialValue;
        this.finalExpression = finalValue;
        this.statements = statements;
    }

    public IdNode getId() {
        return id;
    }

    public void setId(IdNode id) {
        this.id = id;
    }

    public ExpressionNode getInitialExpression() {
        return initialExpression;
    }

    public void setInitialExpression(ExpressionNode initialExpression) {
        this.initialExpression = initialExpression;
    }

    public ExpressionNode getFinalExpression() {
        return finalExpression;
    }

    public void setFinalExpression(ExpressionNode finalExpression) {
        this.finalExpression = finalExpression;
    }

    public List<StatementNode> getStatements() {
        return statements;
    }

    public void setStatements(List<StatementNode> statements) {
        this.statements = statements;
    }
    ExpressionNode initialExpression;
    ExpressionNode finalExpression;
    List<StatementNode> statements;

    @Override
    public void semanticValidation() throws Exception {
        Type tid = id.evaluateType();
        Type tinitial = initialExpression.evaluateType();
        Type tfinal = finalExpression.evaluateType();
        if(!(tid instanceof IntegerType && tfinal instanceof IntegerType && tfinal instanceof IntegerType)){
            throw new Exception("For initializer or finalExpression is not a integer");
        }
        ContextManager contextM = Utils.getInstance();
        Contex c = new Contex(ContextType.FOR);
        c.addVariable(id.getName(), tid);
        contextM.pushFront(c);
        for(int i =0; i < statements.size(); i++){
            statements.get(i).semanticValidation();
        }
        contextM.popFrontContext();
    }



}
