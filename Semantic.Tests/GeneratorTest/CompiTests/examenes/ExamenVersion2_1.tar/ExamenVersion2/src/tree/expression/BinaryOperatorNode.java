/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.expression;

import java.util.HashMap;
import types.Type;
import values.Value;

/**
 *
 * @author Eduardo
 */
public abstract class BinaryOperatorNode extends ExpressionNode{
    ExpressionNode raito;
    ExpressionNode leftou;
    public HashMap<String, Type> rules = new HashMap<>();
    public BinaryOperatorNode(ExpressionNode raito, ExpressionNode leftou) {
        this.raito = raito;
        this.leftou = leftou;
    }

    public ExpressionNode getRaito() {
        return raito;
    }

    public void setRaito(ExpressionNode raito) {
        this.raito = raito;
    }

    public ExpressionNode getLeftou() {
        return leftou;
    }

    public void setLeftou(ExpressionNode leftou) {
        this.leftou = leftou;
    }
    
        @Override
    public Type evaluateType() throws Exception{
        Type tleft = leftou.evaluateType();
        Type riType = raito.evaluateType();
        
        String rule = tleft.getClass().getName()+","+riType.getClass().getName();
        if(!rules.containsKey(rule))
            throw new Exception("Rule "+rule+" is not suported.");
        return rules.get(rule);
    }

}
