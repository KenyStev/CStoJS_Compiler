/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.expression;

import general.Utils;
import types.BooleanType;
import types.FloatType;
import types.IntegerType;
import types.Type;
import values.IntegerValue;
import values.Value;

/**
 *
 * @author Eduardo
 */
public class MultNode extends BinaryOperatorNode{

    public MultNode(ExpressionNode raito, ExpressionNode leftou) {
        super(raito, leftou);
        rules.put(Utils.Int+","+Utils.Int, new IntegerType());
        rules.put(Utils.Float+","+Utils.Float, new FloatType());
    }
}
