/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.expression;

import general.Utils;
import types.FloatType;
import types.IntegerType;
import types.Type;
import values.Value;

/**
 *
 * @author Eduardo
 */
public class DivNode extends BinaryOperatorNode{

    public DivNode(ExpressionNode raito, ExpressionNode leftou) {
        super(raito, leftou);
        rules.put(Utils.Int+","+Utils.Int,new IntegerType());
        rules.put(Utils.Int+","+Utils.Float,new FloatType());
        rules.put(Utils.Float+","+Utils.Int,new FloatType());
    }
}
