/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.statement;

/**
 *
 * @author Eduardo
 */
public abstract class StatementNode {
    public abstract void semanticValidation() throws Exception;
}
