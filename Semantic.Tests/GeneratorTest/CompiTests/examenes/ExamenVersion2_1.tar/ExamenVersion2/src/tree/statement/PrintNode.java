/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tree.statement;

import tree.expression.ExpressionNode;
import types.ArrayType;
import types.Type;

/**
 *
 * @author Eduardo
 */
public class PrintNode extends StatementNode{
    
    ExpressionNode value;

    public PrintNode(ExpressionNode value) {
        this.value = value;
    }

    public ExpressionNode getValue() {
        return value;
    }

    public void setValue(ExpressionNode value) {
        this.value = value;
    }

    @Override
    public void semanticValidation()throws Exception{
        Type t = value.evaluateType();
        if(t instanceof ArrayType){
            throw new Exception("Trying to print an array.");
        }
    }

}
