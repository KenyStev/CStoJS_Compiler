/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package general;

import java.util.ArrayList;
import java.util.List;
import types.Type;

/**
 *
 * @author isaula
 */
public class ContextManager {
    public List<Contex> contexts;

    public ContextManager() {
        contexts = new ArrayList<>();
    }

    public void pushFront(Contex context) {
        contexts.add(0, context);
    }

    public void popFrontContext() throws Exception{
        if(checkIfFunctionContextIsBeforeMe()){
            List<Type> returns = contexts.get(0).returns;
            if(returns.size() == 0){
                throw new Exception("Context is inside function and does not returns anything.");
            }
        }
        contexts.remove(0);
    }

    public boolean AmIInside(int TYPE) {
        for(int i = 0; i < contexts.size(); i++){
            if(contexts.get(i).contextType == TYPE)
                return true;
        }
        return false;
    }

    public void addReturn(Type evaluateType) throws Exception{
        if(contexts.size() <=0)
            throw new Exception("trying to add a return and is not a context in context list.");
        contexts.get(0).addReturn(evaluateType);
    }

    private boolean checkIfFunctionContextIsBeforeMe() {
        for(int i =0; i < contexts.size(); i++){
            if(contexts.get(0).contextType == ContextType.FUNCTION){
                return true;
            }
        }
        return false;
    }
    
}
