/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package general;

import java.util.ArrayList;
import java.util.List;
import types.BooleanType;
import types.CharType;
import types.IntegerType;
import types.StringType;
import types.Type;

/**
 *
 * @author isaula
 */
public class Utils {

    static ContextManager contextManager;
    public static String Int = IntegerType.class.getName();
    public static String Bool = BooleanType.class.getName();
    public static String Char = CharType.class.getName();
    public static String Float = IntegerType.class.getName();
    public static String String = StringType.class.getName();
    public static ContextManager getInstance(){
        if(contextManager == null)
            contextManager = new ContextManager();
        return contextManager;
    }
    
    public static String getMethodName(String name, ArrayList<ParameterDecl> params) {
        String funcname = name+"(" + getParametersType(params)+")";
        return funcname;
    }

    private static String getParametersType(ArrayList<ParameterDecl> params) {
        List<String> names = new ArrayList<>();
        for(int i =0; i< params.size(); i++){
            String name = params.get(i).getType().getClass().getName();
            names.add(name);
        }
        return String.join(",", names);
    }

}
