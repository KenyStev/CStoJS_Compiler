/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package general;

/**
 *
 * @author isaula
 */
public class ContextType {
    public static final int FUNCTION = 0;
    public static int FOR = 1;
    public static int WHILE = 2;
    public static int IF = 3;
    public static int ELSE = 4;
}
