/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import types.Type;

/**
 *
 * @author isaula
 */
public class Contex {
    public HashMap<String, Type> variables;
    public int contextType;
    public List<Type> returns;
    public Contex(int contextType) {
        variables = new HashMap<>();
        this.contextType = contextType;
        returns = new ArrayList<>();
    }    
    
    public void addVariable(String name, Type type) throws Exception{
        if(variables.containsKey(name))
            throw new Exception("variable "+name+" already exist in current context.");
        variables.put(name, type);
    }
    public void addReturn(Type t){
        returns.add(t);
    }
    void addVariable(ArrayList<ParameterDecl> parameterList) throws Exception{
        for(int i = 0; i< parameterList.size(); i++){
            addVariable(parameterList.get(i).getName(), parameterList.get(i).getType());
        }
    }
    
}
