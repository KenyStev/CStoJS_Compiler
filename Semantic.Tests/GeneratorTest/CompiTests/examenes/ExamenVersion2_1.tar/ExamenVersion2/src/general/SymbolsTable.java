package general;

import java.util.ArrayList;
import java.util.HashMap;
import tree.statement.StatementNode;
import types.IntegerType;
import types.Type;
import values.IntegerValue;
import values.Value;

import java.util.Hashtable;

/**
 * Created by mac on 11/19/14.
 */
public class SymbolsTable
{

    private static SymbolsTable instance;
    public static HashMap<String, Type> symbolsTable = new HashMap<String, Type>();
    public static HashMap<String, Function> functionsTable = new HashMap<String, Function>();
    private SymbolsTable()
    {
        
    }

    public static SymbolsTable getInstance()
    {
        if(instance==null)
            instance = new SymbolsTable();
        return instance;
    }



    public void declareVariable(String name,Type type) throws Exception {
        if(symbolsTable.containsKey(name))
            throw new Exception("variable "+name+" already exist.");
        symbolsTable.put(name, type);
    }

    public Type getVariableType(String name) throws Exception {
         if(symbolsTable.containsKey(name))
             return symbolsTable.get(name);
         
         throw new Exception("variable "+name+" not found.");
    }

    public void declareFunction(String name,Function functionInfo) throws Exception {
        ArrayList<ParameterDecl> params = functionInfo.getParameterList();
        String functname = Utils.getMethodName(name, params);
        if(functionsTable.containsKey(functname))
            throw new Exception("Function "+name+" already exist in functions table.");
        if(symbolsTable.containsKey(name))
            throw new Exception("Function name "+name+" already exist in symbolsTable.");
        
        for(int i = 0; i < params.size(); i++){
            if(params.get(i).name == name)
                throw new Exception("params in funcion "+name+" cant be named as function name");
        }
        functionInfo.semanticValidation();
        functionsTable.put(functname, functionInfo);
    }


}
