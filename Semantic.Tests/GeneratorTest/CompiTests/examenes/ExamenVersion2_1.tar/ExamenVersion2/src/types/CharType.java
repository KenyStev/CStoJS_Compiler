package types;

import values.Value;

/**
 * Created by mac on 11/19/14.
 */
public class CharType extends Type {

}
