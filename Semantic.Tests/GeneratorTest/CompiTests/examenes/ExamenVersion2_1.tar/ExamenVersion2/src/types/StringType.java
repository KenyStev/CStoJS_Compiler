package types;

import values.*;

/**
 * Created by mac on 11/19/14.
 */
public class StringType extends Type {

}
